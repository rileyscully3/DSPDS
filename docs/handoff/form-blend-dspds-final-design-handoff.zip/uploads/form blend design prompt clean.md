I am providing a complete product and technical specification titled **Form Blend + DSPDS — Codex Build Specification v2**.

Read the entire attached PDF before beginning. Treat it as the authoritative source for product purpose, scenario behavior, terminology, technical constraints, milestones, data relationships, and acceptance criteria.

Your task is to create the complete UI/UX design and implementation handoff for this application.

**Product overview**

This is a desktop HTML-based 3D aim-form training and spatial-motor assessment application.

Its two major systems are:

1. **DSPDS — Digital-Spatial Predilection Detection System**
    DSPDS studies how a user intuitively translates visible spatial movement into physical mouse movement when normal camera and reticle feedback are removed.
    It creates an evolving, versioned sketch of the user's internal spatial-reasoning model for aiming.
2. **Form Blend**
    Form Blend trains the user to combine:
    * Arm movement for large primary sweeps.
    * Wrist movement for smaller secondary flicks.
    * Fingertip movement for final micro-adjustments.
    * Controlled transitions between those movement scales.

The application prioritizes:

1. Transferable improvement in actual games.
2. Reduced jitter and corrective dependence.
3. Better arm, wrist, and fingertip blending.
4. Understanding the user's internal spatial model.
5. Interesting but useful analysis and visualization.
6. Identifying directional weaknesses.
7. Better stopping control.
8. Finding an intuitive sensitivity range.

**Your role**

You are responsible for the visual and interaction design, not for redefining the product.

Do not remove, merge, reinterpret, or simplify specialized workflows merely to make the interface resemble a conventional aim trainer.

Do not invent new training mechanics that conflict with the attached specification.

Where the specification leaves a visual decision open, make a confident and internally consistent design decision rather than repeatedly asking for clarification.

Only surface a question if a genuine contradiction prevents a responsible design decision.

**Desired visual direction**

Create a hybrid of:

* The restrained, spatially clear feel of a modern 3D aim-training laboratory.
* The organic, readable, analysis-compression philosophy of Fabled Aim.
* Minimal visual interruption during active exercises.
* Richer explanatory depth after a run.
* A serious motor-learning tool rather than an arcade game.
* High visual polish without decorative clutter.

The interface must not feel like:

* A generic neon gaming dashboard.
* An esports statistics website.
* A medical application.
* A spreadsheet placed over a 3D scene.
* A cheap browser game.
* A sci-fi HUD overloaded with lines and glowing panels.

Avoid excessive cyan, purple, neon gradients, glassmorphism, tiny technical labels, dense data tables, and constant live telemetry.

The visual language should feel calm, precise, spatial, intentional, and credible.

**Platform and layout assumptions**

Design for:

* Windows desktop.
* Chrome or Edge.
* Mouse and keyboard.
* 16:9 displays.
* 1920×1080 and 2560×1440 as primary target resolutions.
* Fullscreen use during training.
* No mobile interface.
* No controller interface.

The training scene is 3D, but the surrounding product interface is HTML/CSS.

**Active-training design principles**

During active DSPDS or Form Blend exercises, show only what is necessary:

* The 3D environment.
* Targets, lines, or required scenario geometry.
* A restrained phase or readiness cue.
* Optional repetition progress.
* Pause access.
* Critical input-status warnings when necessary.

Do not show during active assessment:

* Live graphs.
* Endpoint error.
* Sensitivity estimates.
* Trial-level overreach or underreach.
* Detailed scores.
* Coaching that changes the user's behavior before the block is complete.

DSPDS formal assessments must avoid giving feedback that contaminates the measurement.

Form Blend may provide concise post-repetition coaching, but it should present one useful correction rather than a data dump.

**Required screens and states**

Design all of the following as a coherent system.

**1. First launch**

Include:

* Concise explanation of what the application does.
* Creation of the initial local user profile.
* Equipment-profile setup.
* Mouse name.
* DPI.
* Desired or current cm/360.
* FOV.
* First-person or third-person preference where relevant.
* Clear explanation that data is stored locally.
* Optional import of a previous JSON profile.
* A path to begin without completing physical cm/360 verification.

The onboarding must feel brief and purposeful.

**2. Home screen**

The home screen should communicate:

* Continue recommended activity.
* Begin DSPDS assessment.
* Enter DSPDS practice.
* Begin Form Blend.
* Run the four-part physical movement baseline.
* Open cm/360 calibration.
* View profile insights.
* View session history.
* Change equipment profile.
* Export or import data.

Do not present every action with equal visual weight.

The primary recommendation should be obvious.

**3. User and equipment profile**

Show the relationship between:

* User profile.
* Equipment profiles.
* Mouse.
* DPI.
* Current sensitivity.
* Measured sensitivity.
* FOV.
* View mode.
* Calibration status.
* DSPDS model version.
* Physical baseline version.
* Session history.

Clearly distinguish:

* Calculated sensitivity.
* Physically verified sensitivity.
* Relative-only data.
* A profile that needs recommended recalibration.

**4. Input setup and diagnostics**

Design states for:

* Pointer lock request.
* Raw or unadjusted mouse input available.
* Raw input unavailable.
* Input sampling active.
* Potential dropped samples.
* Browser incompatibility.
* Successful input gate.
* Diagnostic details available through progressive disclosure.

The main experience should state whether the system is trustworthy without requiring the user to interpret technical logs.

**5. Physical cm/360 tester**

Design the complete guided flow:

* Explanation and physical preparation.
* Mark the right edge of the mouse.
* Align with a visual reference.
* Click to begin.
* Rotate exactly 360 degrees.
* Click to end.
* Measure physical distance.
* Enter the measured value.
* Repeat for three runs.
* Review average and variation.
* Compare entered DPI with estimated effective behavior.
* Save, retry, or retain the previous profile.

The tester must remain accessible from:

* Initial setup.
* Home.
* Pause.
* Equipment profile.
* Relevant DSPDS results.

It is optional, not a blocker.

**6. DSPDS scenario selection**

Present the five systems without making them feel like unrelated minigames:

* Single-target displacement.
* Chained target flicking.
* Predictable camera-follow tracking.
* Dynamic target-follow tracking.
* Straight-line tracing.

Clearly distinguish:

* Formal assessment.
* Practice mode.
* Official model-updating status.
* Estimated duration.
* Previous completion.
* Current recommendation.

Only formal assessments update the official spatial model.

Practice sessions remain archived separately.

**7. DSPDS instructional screens**

Create a concise instructional state for every DSPDS scenario.

The user must understand:

* What will remain visually controlled by the application.
* That the mouse will not move the camera or reticle.
* What physical movement the user should perform.
* How the trial ends.
* That targets are treated as acquired regardless of movement accuracy.
* Why immediate feedback is intentionally withheld during formal assessment.

Use animation, diagrams, or a tiny demonstration rather than long paragraphs wherever possible.

**8. DSPDS active states**

Design the 3D presentation and minimal overlays for:

**Single-target displacement**

* Flat wall.
* One sphere at an angular offset.
* Fixed camera.
* No reticle.
* No visible response to mouse movement.

**Chained target flicking**

* Current and next target visible.
* No camera movement during the physical flick.
* Short automatic camera reorientation after completion.
* Clear active-target hierarchy without excessive highlighting.

**Predictable camera-follow tracking**

* Camera automatically follows the target.
* Target remains approximately centered.
* Environment motion makes camera rotation understandable.
* User physically mirrors the motion without controlling it.

**Dynamic target-follow tracking**

Design both:

* Static-camera invisible-reticle interpretation.
* Automatically tracking-camera interpretation.

**Straight-line tracing**

* Line grows progressively.
* No visible cursor or reticle.
* Clear start cue and direction.
* Neutral physical-repositioning state when necessary.

Also design:

* Automatic completion.
* Click-to-complete.
* Automatic with click failsafe.
* Pause.
* Abort.
* Recenter or neutral reposition.
* Input interruption.
* Recovery after accidental refresh.

**9. DSPDS assessment results**

The formal result should explain an evolving spatial model, not merely issue a score.

Design a layered presentation showing:

* Intuitive movement-to-angle mapping.
* Central sensitivity estimate.
* Preferred sensitivity range.
* Confidence.
* Separate micro, small, medium, and large movement estimates.
* Left and right discrepancy.
* Horizontal, vertical, and diagonal behavior.
* Overreach and underreach.
* Movement consistency.
* Tracking phase lag.
* Reversal behavior.
* Stopping tails.
* Differences between intuitive movement and actual closed-loop performance when such data exists.
* Change from earlier formal assessments.
* Clear explanation of what updated the official model.

Use progressive disclosure:

1. Plain-language summary.
2. Key visual model.
3. Most actionable findings.
4. Deeper analysis.
5. Raw or technical inspection.

Avoid declaring a mathematically perfect sensitivity.

The interface must make uncertainty and confidence understandable.

**10. DSPDS history and evolving model**

Design a historical view that preserves immutable formal assessments.

Show:

* Assessment dates or ordered versions.
* Model changes over time.
* Stable traits.
* Traits that may be changing.
* Confidence changes.
* Practice history kept separate.
* Comparison between any two formal assessments.
* Current official model.
* Archived earlier models.

Avoid presenting improvement where the evidence is merely variable.

**11. Four-part physical movement baseline**

Create the guided flow for:

* Arm-primary aiming.
* Wrist-primary aiming.
* Fingertip-primary aiming.
* Freestyle or blended aiming.

Instructions should be concise and natural.

The user should not see detailed results during a block.

The result should compare:

* Speed.
* Accuracy.
* Smoothness.
* Precision.
* Stopping.
* Corrections.
* Directional behavior.
* Movement-envelope characteristics.

The interface must be clear that later phase similarity is probabilistic and does not prove which anatomical structure produced a movement.

**12. Form Blend training**

Design the full exercise progression:

* Demonstration.
* Hard-stop assistance.
* Reduced hard stop.
* Soft damping.
* Cue-only training.
* Fully unassisted training.

The repetition includes:

1. Large primary sweep.
2. Controlled transition.
3. Smaller secondary flick.
4. Final micro-adjustment.
5. Click.

The visual system should make these phases feel like one continuous movement problem rather than separate targets.

Design:

* Primary sweep geometry.
* Transition or catch zone.
* Secondary target.
* Micro target.
* Camera freeze during hard-stop assistance.
* Soft damping presentation.
* Phase completion.
* Major failure.
* Minor form violation.
* Successful repetition.
* One-action coaching after the repetition.
* Progression to reduced assistance.

Do not allow a hit to visually imply perfect form.

**13. Form Blend post-repetition feedback**

Show:

* Whether the repetition completed.
* Primary movement quality.
* Transition quality.
* Secondary flick quality.
* Micro-control quality.
* One main coaching instruction.
* Optional deeper inspection.

Possible feedback language includes:

* Clean sweep.
* Carried through the transition.
* Secondary movement started early.
* Repeated correction dependency.
* Final adjustment was rushed.
* Click occurred before settling.

The weakest phase should remain visually important without reducing the entire experience to a single opaque score.

**14. Session review**

Design a review system containing:

* Plain-language session summary.
* Most important improvement.
* Most important persistent issue.
* Directional comparison.
* Assistance level progression.
* Rep timeline.
* Selected-repetition replay.
* Intended and reconstructed paths.
* Stopping tails.
* Correction behavior.
* Comparison to relevant baseline.
* Recommended next activity.

Visualizations should clarify movement rather than merely decorate the report.

**15. Trends and profile insights**

Create an organic, readable overview of:

* Transferable improvement indicators.
* Jitter and corrective dependence.
* Movement blending.
* Internal spatial-model stability.
* Directional weaknesses.
* Stopping control.
* Sensitivity findings.
* Confidence and data sufficiency.
* Equipment-profile differences.

Do not use a grid of dozens of KPI cards.

Lead with conclusions, then provide supporting evidence.

**16. Pause menu**

Include:

* Resume.
* Restart repetition or block where valid.
* Completion-mode selector for DSPDS.
* Sensitivity and FOV visibility.
* Open cm/360 tester.
* Input-status summary.
* Recenter mouse.
* Exit to home.
* Save and exit.
* Abort formal assessment with a clear explanation of whether partial data is retained.

Avoid making the pause menu visually unrelated to the rest of the application.

**17. Data management**

Design:

* Export full profile.
* Export selected session.
* Import profile.
* Import conflict handling.
* Storage usage.
* Raw-data retention.
* Pinned sessions.
* Recovery state.
* Destructive reset.
* Confirmation and rollback where feasible.

**Design system deliverables**

Create a complete and reusable design system including:

* Color tokens.
* Surface hierarchy.
* Typography hierarchy.
* Spacing system.
* Border and radius rules.
* Elevation or depth treatment.
* Iconography direction.
* Motion principles.
* Focus states.
* Hover states.
* Selected states.
* Disabled states.
* Warning and error states.
* Confidence states.
* Assessment versus practice distinction.
* Formal model versus exploratory data distinction.
* Chart and visualization language.
* 3D target and environment material language.

Design for accessibility and legibility without making the application feel visually generic.

**Motion and transition requirements**

Specify motion behavior for:

* Entering a training scene.
* Ready countdown.
* Target activation.
* Automatic camera snap.
* Smooth camera tracking.
* Hard-stop freeze.
* Soft damping.
* Rep completion.
* Rep failure.
* Results reveal.
* Navigating between summary and deeper analysis.
* Equipment-profile change.
* Recovery after interruption.

Motion should communicate state and spatial relationships, not serve as decoration.

**Codex handoff requirements**

Produce an implementation-ready handoff that includes:

* Complete screen inventory.
* Interactive prototype covering primary flows.
* Design tokens.
* Component inventory.
* Component states.
* Layout measurements and responsive rules.
* Typography and spacing specifications.
* Interaction annotations.
* Animation durations and easing guidance.
* Asset inventory.
* 3D scene appearance guidance.
* Accessibility requirements.
* Error, empty, loading, recovery, and incomplete-data states.
* Explicit identification of which values are examples versus functional requirements.
* Notes identifying any design decision you made where the PDF left visual discretion.
* A concise implementation priority guide for Codex.

Use realistic example data, but clearly label it as illustrative.

Do not encode fabricated scientific certainty into the interface.

**Required prototype flows**

The interactive prototype must demonstrate at least:

1. First launch → equipment setup → home.
2. Home → DSPDS formal assessment → scenario instruction → active trial → block result → official model update.
3. Home → DSPDS practice → active practice → separate practice result.
4. Home → physical cm/360 tester → three measurements → save.
5. Home → four-part movement baseline → result.
6. Home → Form Blend demonstration → assisted repetition → feedback → progression.
7. Home → profile insights → historical DSPDS model comparison.
8. Pause → completion-mode change → resume.
9. Interrupted session → recovery.
10. Export and import flow.

**Quality bar**

The design must make the application feel:

* Technically trustworthy.
* Visually polished.
* Fast.
* Serious about motor learning.
* Easy to begin using.
* Clear about how conclusions were reached.
* Capable of becoming a tool the user repeatedly returns to.

The design fails if:

* It feels visually cheap.
* It appears laggy or cumbersome.
* Navigation is confusing.
* Results look arbitrary.
* Important conclusions are buried.
* Setup obstructs training.
* It provides data without useful knowledge.
* It looks like a generic gaming template.
* The distinction between formal DSPDS assessment and practice is unclear.

Begin by synthesizing the attached specification into a screen map and visual direction. Then build the complete cohesive design and prototype rather than stopping at exploratory moodboards or disconnected screen concepts.
